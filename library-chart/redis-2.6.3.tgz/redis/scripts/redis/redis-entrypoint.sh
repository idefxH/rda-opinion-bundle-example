#!/bin/bash
#
# Entrypoint for Redis container images

# Strict mode
set -euo pipefail

# Load functions used by the script
# shellcheck disable=SC1091
. /mnt/redis/scripts/functions.sh
# shellcheck disable=SC1091
. /mnt/redis/scripts/redis-functions.sh

if [[ ! -e $_REDIS_CONF_FILE ]]; then
    log "Generating Redis configuration file"
    redis_conf >"$_REDIS_CONF_FILE"
else
    log "Detected an existing Redis configuration file"
fi

log "Starting Redis"
exec redis-server "$_REDIS_CONF_FILE" "$@" -
