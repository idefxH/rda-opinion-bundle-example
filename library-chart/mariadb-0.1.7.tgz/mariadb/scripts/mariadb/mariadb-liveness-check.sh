#!/bin/bash
#
# Liveness check script for MariaDB containers

# Strict mode
set -euo pipefail

# Load functions used by the script
# shellcheck disable=SC1091
. /mnt/mariadb/scripts/mariadb-functions.sh

command_flags=()
if [[ -n ${_MARIADB_DATADIR:-} ]]; then
    command_flags+=(
        "--datadir=${_MARIADB_DATADIR}"
        "--defaults-extra-file=${_MARIADB_DATADIR}/.my-healthcheck.cnf"
    )
fi
if mariadb_is_primary; then
    exec healthcheck.sh "${command_flags[@]}" --innodb_initialized
else
    exec healthcheck.sh "${command_flags[@]}" --innodb_initialized \
        --replication_io --replication
fi
