#!/bin/bash
#
# Common functions for MariaDB

# @description Check whether the current MariaDB node is a primary or not.
#
# @exitcode 0 If the current MariaDB node is a primary node.
# @exitcode 1 If the current MariaDB node is NOT a primary node.
mariadb_is_primary() {
    [[ ${_MARIADB_MASTER_HOST:-} == "$HOSTNAME."* ]]
}
