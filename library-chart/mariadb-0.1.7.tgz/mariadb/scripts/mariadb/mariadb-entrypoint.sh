#!/bin/bash
#
# Entrypoint for MariaDB container images

# Strict mode
set -euo pipefail

# Load functions used by the script
# shellcheck disable=SC1091
. /mnt/mariadb/scripts/functions.sh
# shellcheck disable=SC1091
. /mnt/mariadb/scripts/mariadb-functions.sh

command_flags=()

if [[ -n ${_MARIADB_DEFAULTS_EXTRA_FILE:-} ]]; then
    command_flags+=("--defaults-extra-file=${_MARIADB_DEFAULTS_EXTRA_FILE}")
fi
if [[ -n ${_MARIADB_PORT:-} ]]; then
    command_flags+=("--port=${_MARIADB_PORT}")
fi
if [[ -n ${_MARIADB_DATADIR:-} ]]; then
    command_flags+=("--datadir=${_MARIADB_DATADIR}")
fi
command_flags+=("--server-id=$(("${HOSTNAME##*-}" + 1))")
command_flags+=('--log-basename=mariadb')
if [[ -n ${_MARIADB_REQUIRE_SECURE_TRANSPORT:-} ]]; then
    command_flags+=('--require-secure-transport')
fi
if [[ -n ${_MARIADB_TLS_CERT:-} ]]; then
    command_flags+=("--ssl-cert=${_MARIADB_TLS_CERT}")
fi
if [[ -n ${_MARIADB_TLS_KEY:-} ]]; then
    command_flags+=("--ssl-key=${_MARIADB_TLS_KEY}")
fi
if [[ -n ${_MARIADB_TLS_CA:-} ]]; then
    command_flags+=("--ssl-ca=${_MARIADB_TLS_CA}")
fi
if mariadb_is_primary; then
    command_flags+=('--log-bin')
    export MARIADB_DATABASE="${_MARIADB_DATABASE:-}"
    export MARIADB_USER="${_MARIADB_USER:-}"
    export MARIADB_PASSWORD="${_MARIADB_PASSWORD:-}"
else
    export MARIADB_MASTER_HOST="${_MARIADB_MASTER_HOST:-}"
    export MARIADB_MASTER_PORT="${_MARIADB_PORT:-}"
    export MARIADB_HEALTHCHECK_GRANTS="\
        ${MARIADB_HEALTHCHECK_GRANTS:-REPLICA MONITOR}"
fi

set -- "${command_flags[@]}" "$@"

log "Starting MariaDB"
exec docker-entrypoint.sh "$@"
