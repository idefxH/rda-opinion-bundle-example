# MariaDB Helm Chart

> [MariaDB](https://mariadb.org) Server is one of the most popular open source relational databases. It's made by the original developers of MySQL and guaranteed to stay open source. It is part of most cloud offerings and the default in most Linux distributions.

## Introduction

This Helm chart bootstraps a [MariaDB](https://mariadb.org) deployment on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Quick Start

```sh
helm install my-release oci://dp.apps.rancher.io/charts/mariadb \
    --set global.imagePullSecrets={application-collection}
```

### Prerequisites

* Helm 3.8.0 or later.
* Kubernetes 1.24 or later.
* PV provisioner support in the underlying infrastructure.

## Install Chart

To install the Helm chart with the release name *my-release*:

```sh
helm install my-release oci://dp.apps.rancher.io/charts/mariadb \
    --set global.imagePullSecrets={application-collection}
```

This deploys the application to the Kubernetes cluster using the default configuration provided by the Helm chart.

> NOTE: You can follow [these steps](https://docs.apps.rancher.io/get-started/authentication/#kubernetes)
> to create and setup the image pull secrets, if you don't have them already.

## Uninstall Chart

To uninstall the Helm chart with the release name *my-release*:

```sh
helm uninstall my-release
```

This removes all the Kubernetes components associated to the Helm chart

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| auth.database | string | `""` | MariaDB database to create. If empty, the database will not be created |
| auth.existingSecret | string | `""` | Name of a secret containing the secret for the MariaDB passwords (if set, `auth.password`, `auth.rootPassword` and `auth.replicationPassword` will be ignored) |
| auth.password | string | `""` | MariaDB password for the user to create |
| auth.passwordKey | string | `"password"` | Password key in the secret @default `password` |
| auth.replicationPassword | string | `""` | Replication password |
| auth.replicationPasswordKey | string | `"replicationPassword"` | Replication user password key in the secret @default `replicationPassword` |
| auth.replicationUsername | string | `"repl"` | Replication username @default `repl` |
| auth.rootPassword | string | `""` | MariaDB password for the MariaDB root superuser |
| auth.rootPasswordKey | string | `"rootPassword"` | MariaDB root superuser password key in the secret @default `rootPassword` |
| auth.username | string | `""` | MariaDB username for the user to create. If empty, the user will not be created |
| clusterDomain | string | `"cluster.local"` | Kubernetes cluster domain name |
| commonAnnotations | object | `{}` | Annotations to add to all deployed objects |
| commonLabels | object | `{}` | Labels to add to all deployed objects |
| configMap | object | See `values.yaml` | ConfigMaps to deploy |
| configMap.* | string | `nil` | Custom configuration file to include, templates are allowed both in the config map name and contents |
| configMap.enabled | string | `true` if `configuration` was provided without existing configmap, `false` otherwise | Create a config map for MariaDB configuration |
| configuration | string | `""` | Extra configurations to be read by MariaDB See: https://mariadb.com/docs/server/server-management/install-and-upgrade-mariadb/configuring-mariadb/configuring-mariadb-with-option-files |
| configurationFile | string | `"extra.cnf"` | Configuration file name in the config map |
| containerPorts.* | int32 | `nil` | Custom port number to expose in the MariaDB containers |
| containerPorts.mariadb | int32 | `3306` | MariaDB port number for client connections |
| containerPorts.metrics | int32 | `9104` | Port number where metrics will be exposed to |
| containerSecurityContext.allowPrivilegeEscalation | bool | `false` | Allow privilege escalation within containers |
| containerSecurityContext.enabled | bool | `true` | Enable container security context |
| containerSecurityContext.runAsNonRoot | bool | `true` | Run containers as a non-root user |
| containerSecurityContext.runAsUser | int | `1000` | Which user ID to run the container as |
| existingConfigMap | string | `""` | Name of an existing config map for extra configuration files to be read by MariaDB |
| extraManifests | list | `[]` | Additional Kubernetes manifests to include in the chart |
| fullnameOverride | string | `""` | Override the resource name |
| global.imagePullSecrets | list | `[]` | Global override for container image registry pull secrets |
| global.imageRegistry | string | `""` | Global override for container image registry |
| global.storageClassName | string | `""` | Global override for the storage class |
| headlessService.* | string | `nil` | Custom attributes for the MariaDB headless service (see [`ServiceSpec` API reference](https://kubernetes.io/docs/reference/kubernetes-api/service-resources/service-v1/#ServiceSpec)) |
| headlessService.annotations | object | `{}` | Custom annotations to add to the headless service for MariaDB |
| headlessService.clusterIP | string | `"None"` |  |
| headlessService.ports.* | int32 | `nil` | Headless service port override for custom MariaDB ports specified in `containerPorts.*` |
| headlessService.ports.mariadb | int32 | `""` | Headless service port override for MariaDB client connections |
| headlessService.publishNotReadyAddresses | bool | `true` | Disregard indications of ready/not-ready The primary use case for setting this field is for a StatefulSet's Headless Service to propagate SRV DNS records for its Pods for the purpose of peer discovery |
| headlessService.type | string | `"ClusterIP"` | MariaDB headless service type |
| images.mariadb.digest | string | `""` | Image digest to use for the MariaDB container (if set, `images.mariadb.tag` will be ignored) |
| images.mariadb.pullPolicy | string | `"IfNotPresent"` | Image pull policy to use for the MariaDB container |
| images.mariadb.registry | string | `"dp.apps.rancher.io"` | Image registry to use for the MariaDB container |
| images.mariadb.repository | string | `"containers/mariadb"` | Image repository to use for the MariaDB container |
| images.mariadb.tag | string | `"11.8.6-5.1"` | Image tag to use for the MariaDB container |
| images.metrics.digest | string | `""` | Image digest to use for the MySQL Server Exporter container (if set, `images.metrics.tag` will be ignored) |
| images.metrics.pullPolicy | string | `"IfNotPresent"` | Image pull policy to use for the MySQL Server Exporter container |
| images.metrics.registry | string | `"dp.apps.rancher.io"` | Image registry to use for the MySQL Server Exporter container |
| images.metrics.repository | string | `"containers/mysqld-exporter"` | Image repository to use for the MySQL Server Exporter container |
| images.metrics.tag | string | `"0.18.0-4.1"` | Image tag to use for the MySQL Server Exporter container |
| images.volume-permissions.digest | string | `""` | Image digest to use for the volume permissions init container (if set, `images.volume-permissions.tag` will be ignored) |
| images.volume-permissions.pullPolicy | string | `"IfNotPresent"` | Image pull policy to use for the volume-permissions container |
| images.volume-permissions.registry | string | `"dp.apps.rancher.io"` | Image registry to use for the volume permissions init container |
| images.volume-permissions.repository | string | `"containers/bci-busybox"` | Image repository to use for the volume permissions init container |
| images.volume-permissions.tag | string | `"15.7-19.10"` | Image tag to use for the volume permissions init container |
| metrics.annotations | object | See `values.yaml` | Annotations to add to all pods that expose metrics |
| metrics.enabled | bool | `false` | Expose MariaDB metrics |
| metrics.prometheusRule.configuration | object | `{}` | Content of the Prometheus rule file See https://prometheus.io/docs/prometheus/latest/configuration/recording_rules/ |
| metrics.prometheusRule.enabled | bool | `false` | Create a PrometheusRule resource (also requires `metrics.enabled` to be enabled) |
| metrics.prometheusRule.labels | object | `{}` | Additional labels that will be added to the PrometheusRule resource |
| metrics.prometheusRule.namespace | string | `""` | Namespace for the PrometheusRule resource (defaults to the release namespace) |
| metrics.service.* | string | `nil` | Custom attributes for the service (see [`ServiceSpec` API reference](https://kubernetes.io/docs/reference/kubernetes-api/service-resources/service-v1/#ServiceSpec)) |
| metrics.service.annotations | object | `{}` | Custom annotations to add to the service for mysqld-exporter |
| metrics.service.enabled | bool | `true` | Create a service for mysqld-exporter (apart from the headless service) |
| metrics.service.nodePorts.* | int32 | `nil` | Service nodePort override for custom ports specified in `containerPorts.*` |
| metrics.service.nodePorts.metrics | int32 | `""` | Service nodePort override for mysqld-exporter metrics connections |
| metrics.service.ports.* | int32 | `nil` | Service port override for custom ports specified in `containerPorts.*` |
| metrics.service.ports.metrics | int32 | `""` | Service port override for mysqld-exporter metrics connections |
| metrics.service.type | string | `"ClusterIP"` | Service type |
| nameOverride | string | `""` | Override the resource name prefix (will keep the release name) |
| networkPolicy.allowExternalConnections | bool | `true` | Allow all external connections from and to the pods |
| networkPolicy.egress.allowExternalConnections | bool | `true` | Allow all external egress connections from the pods (requires also `networkPolicy.allowExternalConnections`) |
| networkPolicy.egress.enabled | bool | `true` | Create an egress network policy (requires also `networkPolicy.enabled`) |
| networkPolicy.egress.extraRules | list | `[]` | Custom additional egress rules to enable in the NetworkPolicy resource |
| networkPolicy.egress.namespaceLabels | object | `{}` | List of namespace labels for which to allow egress connections, when external connections are disallowed |
| networkPolicy.egress.podLabels | object | `{}` | List of pod labels for which to allow egress connections, when external connections are disallowed |
| networkPolicy.egress.ports.* | int32 | `nil` | Network policy port override for custom ports specified in `containerPorts.*` for egress connections |
| networkPolicy.egress.ports.mariadb | int32 | `""` | Network policy port override for MariaDB client connections for egress connections |
| networkPolicy.egress.ports.metrics | int32 | `""` | Network policy port override for metrics connections for egress connections |
| networkPolicy.enabled | bool | `false` | Create a NetworkPolicy resource for MariaDB |
| networkPolicy.ingress.allowExternalConnections | bool | `true` | Allow all external ingress connections to the pods (requires also `networkPolicy.allowExternalConnections`) |
| networkPolicy.ingress.enabled | bool | `true` | Create an ingress network policy (requires also `networkPolicy.enabled`) |
| networkPolicy.ingress.extraRules | list | `[]` | Custom additional ingress rules to enable in the NetworkPolicy resource |
| networkPolicy.ingress.namespaceLabels | object | `{}` | List of namespace labels for which to allow ingress connections, when external connections are disallowed |
| networkPolicy.ingress.podLabels | object | `{}` | List of pod labels for which to allow ingress connections, when external connections are disallowed |
| networkPolicy.ingress.ports.* | int32 | `nil` | Network policy port override for custom ports specified in `containerPorts.*` for ingress connections |
| networkPolicy.ingress.ports.mariadb | int32 | `""` | Network policy port override for MariaDB client connections for ingress connections |
| networkPolicy.ingress.ports.metrics | int32 | `""` | Network policy port override for metrics connections for ingress connections |
| nodeCount | int | `1` | Desired number of MariaDB nodes to deploy (counting the MariaDB primary node) |
| persistence.accessModes | list | `["ReadWriteOnce"]` | Persistent volume access modes |
| persistence.annotations | object | `{}` | Custom annotations to add to the persistent volume claims used by MariaDB pods |
| persistence.enabled | bool | `true` | Enable persistent volume claims for MariaDB pods |
| persistence.existingClaim | string | `""` | Name of an existing PersistentVolumeClaim to use by MariaDB pods |
| persistence.labels | object | `{}` | Custom labels to add to the persistent volume claims used by MariaDB pods |
| persistence.resources.requests.storage | string | `"8Gi"` | Size of the persistent volume claim to create for MariaDB pods |
| persistence.storageClassName | string | `""` | Storage class name to use for the MariaDB persistent volume claim |
| podDisruptionBudget.enabled | bool | `false` | Create a pod disruption budget for MariaDB |
| podDisruptionBudget.maxUnavailable | string | `""` | Number of pods from that can be unavailable after the eviction, this option is mutually exclusive with minAvailable |
| podDisruptionBudget.minAvailable | string | `""` | Number of pods from that set that must still be available after the eviction, this option is mutually exclusive with maxUnavailable |
| podSecurityContext.enabled | bool | `true` | Enable pod security context |
| podSecurityContext.fsGroup | int | `1000` | Group ID that will write to persistent volumes |
| podTemplates.* | string | `nil` | Custom attributes for the pods in the MariaDB PodTemplate (see [`PodSpec` API reference](https://kubernetes.io/docs/reference/kubernetes-api/workload-resources/pod-v1/#PodSpec)) |
| podTemplates.annotations | object | See `values.yaml` | Annotations to add to all pods in the MariaDB StatefulSet's PodTemplate |
| podTemplates.containers | object | See `values.yaml` | Containers to deploy in the MariaDB PodTemplate Each field has the container name as key, and a YAML object template with the values; you must set `enabled: true` to enable it |
| podTemplates.containers.mariadb.* | string | `nil` | Custom attributes for the MariaDB container (see [`Container` API spec](https://kubernetes.io/docs/reference/kubernetes-api/workload-resources/pod-v1/#Container)) |
| podTemplates.containers.mariadb.args | list | `[]` | Arguments override for the MariaDB container entrypoint |
| podTemplates.containers.mariadb.command | list | See `values.yaml` | Entrypoint override for the MariaDB container |
| podTemplates.containers.mariadb.enabled | bool | `true` | Enable the MariaDB container in the PodTemplate |
| podTemplates.containers.mariadb.env | object | See `values.yaml` | Object with the environment variables templates to use in the MariaDB container, the values can be specified as an object or a string; when using objects you must also set `enabled: true` to enable it |
| podTemplates.containers.mariadb.envFrom | list | `[]` | List of sources from which to populate environment variables to the MariaDB container (e.g. a ConfigMaps or a Secret) |
| podTemplates.containers.mariadb.image | string | `""` | Image override for the MariaDB container (if set, `images.mariadb.{name,tag,digest}` values will be ignored for this container) |
| podTemplates.containers.mariadb.imagePullPolicy | string | `""` | Image pull policy override for the MariaDB container (if set `images.mariadb.pullPolicy` values will be ignored for this container) |
| podTemplates.containers.mariadb.livenessProbe.enabled | bool | `true` | Enable liveness probe for MariaDB |
| podTemplates.containers.mariadb.livenessProbe.exec | object | See `values.yaml` | Command to execute for the MariaDB startup probe |
| podTemplates.containers.mariadb.livenessProbe.failureThreshold | int | `5` | Minimum consecutive failures for the MariaDB liveness probe to be considered failed after having succeeded |
| podTemplates.containers.mariadb.livenessProbe.initialDelaySeconds | int | `10` | Number of seconds after the MariaDB container has started before liveness probes are initiated |
| podTemplates.containers.mariadb.livenessProbe.periodSeconds | int | `10` | How often (in seconds) to perform the MariaDB liveness probe |
| podTemplates.containers.mariadb.livenessProbe.successThreshold | int | `1` | Minimum consecutive successes for the MariaDB liveness probe to be considered successful after having failed |
| podTemplates.containers.mariadb.livenessProbe.timeoutSeconds | int | `5` | Number of seconds after which the MariaDB liveness probe times out |
| podTemplates.containers.mariadb.ports | object | `{}` | Ports override for the MariaDB container (if set, `containerPorts.*` values will be ignored for this container) |
| podTemplates.containers.mariadb.readinessProbe.enabled | bool | `true` | Enable readiness probe for MariaDB |
| podTemplates.containers.mariadb.readinessProbe.exec | object | See `values.yaml` | Command to execute for the MariaDB startup probe |
| podTemplates.containers.mariadb.readinessProbe.failureThreshold | int | `5` | Minimum consecutive failures for the MariaDB readiness probe to be considered failed after having succeeded |
| podTemplates.containers.mariadb.readinessProbe.initialDelaySeconds | int | `10` | Number of seconds after the MariaDB container has started before readiness probes are initiated |
| podTemplates.containers.mariadb.readinessProbe.periodSeconds | int | `10` | How often (in seconds) to perform the MariaDB readiness probe |
| podTemplates.containers.mariadb.readinessProbe.successThreshold | int | `1` | Minimum consecutive successes for the MariaDB readiness probe to be considered successful after having failed |
| podTemplates.containers.mariadb.readinessProbe.timeoutSeconds | int | `5` | Number of seconds after which the MariaDB readiness probe times out |
| podTemplates.containers.mariadb.resources | object | `{}` | Custom resource requirements for the MariaDB container |
| podTemplates.containers.mariadb.securityContext | object | `{}` | Security context override for the MariaDB container (if set, `containerSecurityContext.*` values will be ignored for this container) |
| podTemplates.containers.mariadb.startupProbe.enabled | bool | `false` | Enable startup probe for MariaDB |
| podTemplates.containers.mariadb.startupProbe.failureThreshold | int | `10` | Minimum consecutive failures for the MariaDB startup probe to be considered failed after having succeeded |
| podTemplates.containers.mariadb.startupProbe.initialDelaySeconds | int | `0` | Number of seconds after the MariaDB container has started before startup probes are initiated |
| podTemplates.containers.mariadb.startupProbe.periodSeconds | int | `10` | How often (in seconds) to perform the MariaDB startup probe |
| podTemplates.containers.mariadb.startupProbe.successThreshold | int | `1` | Minimum consecutive successes for the MariaDB startup probe to be considered successful after having failed |
| podTemplates.containers.mariadb.startupProbe.tcpSocket | object | See `values.yaml` | Port number used to check if the MariaDB service is alive |
| podTemplates.containers.mariadb.startupProbe.timeoutSeconds | int | `5` | Number of seconds after which the MariaDB startup probe times out |
| podTemplates.containers.mariadb.volumeMounts | object | See `values.yaml` | Volume mount templates for the MariaDB container, templates are allowed in all fields Each field has the volume mount name as key, and a YAML string template with the values; you must set `enabled: true` to enable it |
| podTemplates.containers.metrics.* | string | `nil` | Custom attributes for the mysqld-exporter container (see [`Container` API spec](https://kubernetes.io/docs/reference/kubernetes-api/workload-resources/pod-v1/#Container)) |
| podTemplates.containers.metrics.args | list | `[]` | Arguments override for the mysqld-exporter container entrypoint |
| podTemplates.containers.metrics.command | list | `["mysqld_exporter","--mysqld.address={{ printf \"127.0.0.1:%d\" (int .Values.containerPorts.mariadb) }}","--mysqld.username=root","--web.listen-address=:{{ .Values.containerPorts.metrics }}"]` | Entrypoint override for the mysqld-exporter container |
| podTemplates.containers.metrics.enabled | string | Same value as `metrics.enabled` | Enable the mysqld-exporter container in the MariaDB PodTemplate |
| podTemplates.containers.metrics.env | object | See `values.yaml` | Object with the environment variables templates to use in the mysqld-exporter container, the values can be specified as an object or a string; when using objects you must also set `enabled: true` to enable it |
| podTemplates.containers.metrics.envFrom | list | `[]` | List of sources from which to populate environment variables to the mysqld-exporter container (e.g. a ConfigMaps or a Secret) |
| podTemplates.containers.metrics.image | string | `""` | Image override for the mysqld-exporter container (if set, `images.metrics.{name,tag,digest}` values will be ignored for this container) |
| podTemplates.containers.metrics.imagePullPolicy | string | `""` | Image pull policy override for the mysqld-exporter container (if set `images.metrics.pullPolicy` values will be ignored for this container) |
| podTemplates.containers.metrics.livenessProbe.enabled | bool | `true` | Enable liveness probe for mysqld-exporter |
| podTemplates.containers.metrics.livenessProbe.failureThreshold | int | `5` | Minimum consecutive failures for the mysqld-exporter liveness probe to be considered failed after having succeeded |
| podTemplates.containers.metrics.livenessProbe.initialDelaySeconds | int | `10` | Number of seconds after the mysqld-exporter container has started before liveness probes are initiated |
| podTemplates.containers.metrics.livenessProbe.periodSeconds | int | `10` | How often (in seconds) to perform the mysqld-exporter liveness probe |
| podTemplates.containers.metrics.livenessProbe.successThreshold | int | `1` | Minimum consecutive successes for the mysqld-exporter liveness probe to be considered successful after having failed |
| podTemplates.containers.metrics.livenessProbe.tcpSocket | object | See `values.yaml` | Port number used to check if the mysqld-exporter service is alive |
| podTemplates.containers.metrics.livenessProbe.timeoutSeconds | int | `5` | Number of seconds after which the mysqld-exporter liveness probe times out |
| podTemplates.containers.metrics.ports | object | `{}` | Ports override for the mysqld-exporter container (if set, `containerPorts.*` values will be ignored for this container) |
| podTemplates.containers.metrics.readinessProbe.enabled | bool | `true` | Enable readiness probe for mysqld-exporter |
| podTemplates.containers.metrics.readinessProbe.failureThreshold | int | `5` | Minimum consecutive failures for the mysqld-exporter readiness probe to be considered failed after having succeeded |
| podTemplates.containers.metrics.readinessProbe.httpGet | object | See `values.yaml` | HTTP endpoint used to check if the mysqld-exporter service is ready |
| podTemplates.containers.metrics.readinessProbe.initialDelaySeconds | int | `10` | Number of seconds after the mysqld-exporter container has started before readiness probes are initiated |
| podTemplates.containers.metrics.readinessProbe.periodSeconds | int | `10` | How often (in seconds) to perform the mysqld-exporter readiness probe |
| podTemplates.containers.metrics.readinessProbe.successThreshold | int | `1` | Minimum consecutive successes for the mysqld-exporter readiness probe to be considered successful after having failed |
| podTemplates.containers.metrics.readinessProbe.timeoutSeconds | int | `5` | Number of seconds after which the mysqld-exporter readiness probe times out |
| podTemplates.containers.metrics.resources | object | `{}` | Custom resource requirements for the mysqld-exporter container |
| podTemplates.containers.metrics.securityContext | object | `{}` | Security context override for the mysqld-exporter container (if set, `containerSecurityContext.*` values will be ignored for this container) |
| podTemplates.containers.metrics.startupProbe.enabled | bool | `false` | Enable startup probe for mysqld-exporter |
| podTemplates.containers.metrics.startupProbe.failureThreshold | int | `10` | Minimum consecutive failures for the mysqld-exporter startup probe to be considered failed after having succeeded |
| podTemplates.containers.metrics.startupProbe.initialDelaySeconds | int | `0` | Number of seconds after the mysqld-exporter container has started before startup probes are initiated |
| podTemplates.containers.metrics.startupProbe.periodSeconds | int | `10` | How often (in seconds) to perform the mysqld-exporter startup probe |
| podTemplates.containers.metrics.startupProbe.successThreshold | int | `1` | Minimum consecutive successes for the mysqld-exporter startup probe to be considered successful after having failed |
| podTemplates.containers.metrics.startupProbe.tcpSocket | object | See `values.yaml` | Port number used to check if the mysqld-exporter service has been started |
| podTemplates.containers.metrics.startupProbe.timeoutSeconds | int | `5` | Number of seconds after which the mysqld-exporter startup probe times out |
| podTemplates.containers.metrics.volumeMounts | object | See `values.yaml` | Volume mount templates for the mysqld-exporter container, templates are allowed in all fields Each field has the volume mount name as key, and a YAML string template with the values; you must set `enabled: true` to enable it |
| podTemplates.imagePullSecrets | list | `[]` | Custom pull secrets for the MariaDB container in the PodTemplate |
| podTemplates.initContainers | object | See `values.yaml` | Init containers to deploy in the MariaDB PodTemplate Each field has the init container name as key, and a YAML object template with the values; you must set `enabled: true` to enable it |
| podTemplates.initContainers.volume-permissions.* | string | `nil` | Custom attributes for the MariaDB volume-permissions init container (see [`Container` API spec](https://kubernetes.io/docs/reference/kubernetes-api/workload-resources/pod-v1/#Container)) |
| podTemplates.initContainers.volume-permissions.args | list | `[]` | Arguments override for the MariaDB volume-permissions init container entrypoint |
| podTemplates.initContainers.volume-permissions.command | list | See `values.yaml` | Entrypoint override for the MariaDB volume-permissions container |
| podTemplates.initContainers.volume-permissions.enabled | bool | `false` | Enable the volume-permissions init container in the MariaDB PodTemplate |
| podTemplates.initContainers.volume-permissions.env | object | No environment variables are set | Object with the environment variables templates to use in the MariaDB volume-permissions init container, the values can be specified as an object or a string; when using objects you must also set `enabled: true` to enable it |
| podTemplates.initContainers.volume-permissions.envFrom | list | `[]` | List of sources from which to populate environment variables to the MariaDB volume-permissions init container (e.g. a ConfigMaps or a Secret) |
| podTemplates.initContainers.volume-permissions.image | string | `""` | Image override for the MariaDB volume-permissions init container (if set, `images.volume-permissions.{name,tag,digest}` values will be ignored for this container) |
| podTemplates.initContainers.volume-permissions.imagePullPolicy | string | `""` | Image pull policy override for the MariaDB volume-permissions init container (if set `images.volume-permissions.pullPolicy` values will be ignored for this container) |
| podTemplates.initContainers.volume-permissions.resources | object | `{}` | MariaDB init-containers resource requirements |
| podTemplates.initContainers.volume-permissions.securityContext | object | See `values.yaml` | Security context override for the MariaDB volume-permissions init container (if set, `containerSecurityContext.*` values will be ignored for this container) |
| podTemplates.initContainers.volume-permissions.volumeMounts | object | See `values.yaml` | Custom volume mounts for the MariaDB volume-permissions init container, templates are allowed in all fields Each field has the volume mount name as key, and a YAML string template with the values; you must set `enabled: true` to enable it |
| podTemplates.labels | object | `{}` | Labels to add to all pods in the MariaDB StatefulSet's PodTemplate |
| podTemplates.securityContext | object | `{}` | Security context override for the pods in the MariaDB PodTemplate (if set, `podSecurityContext.*` values will be ignored) |
| podTemplates.serviceAccountName | string | `""` | Service account name override for the pods in the MariaDB PodTemplate (if set, `serviceAccount.name` will be ignored) |
| podTemplates.volumes | object | See `values.yaml` | Volume templates for the MariaDB PodTemplate, templates are allowed in all fields Each field has the volume name as key, and a YAML string template with the values; you must set `enabled: true` to enable it |
| secret | object | See `values.yaml` | Secrets to deploy |
| secret.* | string | `nil` | Custom secret to include, templates are allowed both in the secret name and contents |
| secret.enabled | string | `true` if authentication is enabled without existing secret, `false` otherwise | Create a secret for MariaDB credentials |
| service.* | string | `nil` | Custom attributes for the MariaDB service (see [`ServiceSpec` API reference](https://kubernetes.io/docs/reference/kubernetes-api/service-resources/service-v1/#ServiceSpec)) |
| service.annotations | object | `{}` | Custom annotations to add to the service for MariaDB |
| service.enabled | bool | `true` | Create a service for MariaDB (apart from the headless service) |
| service.nodePorts.* | int32 | `nil` | Service nodePort override for custom MariaDB ports specified in `containerPorts.*` |
| service.nodePorts.mariadb | int32 | `""` | Service nodePort override for MariaDB client connections |
| service.ports.* | int32 | `nil` | Service port override for custom MariaDB ports specified in `containerPorts.*` |
| service.ports.mariadb | int32 | `""` | Service port override for MariaDB client connections |
| service.type | string | `"ClusterIP"` | MariaDB service type |
| serviceAccount.annotations | object | `{}` | Add custom annotations to the ServiceAccount |
| serviceAccount.automountServiceAccountToken | bool | `true` | Whether pods running as this service account should have an API token automatically mounted |
| serviceAccount.enabled | bool | `false` | Create or use an existing service account for MariaDB |
| serviceAccount.imagePullSecrets | list | `[]` | List of references to secrets in the same namespace to use for pulling any images in pods that reference this ServiceAccount |
| serviceAccount.labels | object | `{}` | Add custom labels to the ServiceAccount |
| serviceAccount.name | string | `""` | Name of the ServiceAccount to use |
| serviceAccount.secrets | list | `[]` | List of secrets in the same namespace that pods running using this ServiceAccount are allowed to use |
| statefulset.* | string | `nil` | Custom attributes for the MariaDB StatefulSet (see [`StatefulSetSpec` API reference](https://kubernetes.io/docs/reference/kubernetes-api/workload-resources/stateful-set-v1/#StatefulSetSpec)) |
| statefulset.enabled | bool | `true` | Enable the StatefulSet template for MariaDB |
| statefulset.persistentVolumeClaimRetentionPolicy | object | `{}` | Lifecycle of the persistent volume claims created from MariaDB volumeClaimTemplates |
| statefulset.podManagementPolicy | string | `"OrderedReady"` | How MariaDB pods are created during the initial scaleup |
| statefulset.replicas | string | `""` | Desired number of PodTemplate replicas for MariaDB (overrides `nodeCount`) |
| statefulset.serviceName | string | `""` | Override for the MariaDB' StatefulSet serviceName field, it will be autogenerated if unset |
| statefulset.template | object | `{}` | Template to use for all pods created by the MariaDB StatefulSet (overrides `podTemplates.*`) |
| statefulset.updateStrategy | object | See `values.yaml` | Strategy that will be employed to update the pods in the MariaDB StatefulSet |
| statefulset.volumeClaimTemplates | object | See `values.yaml` | Volume claim templates for the MariaDB StatefulSet, templates are allowed in all fields Each field has the volumeClaimTemplate name as key, and a YAML string template with the values; you must set `enabled: true` to enable it |
| tls.caCertFilename | string | `""` | CA certificate filename in the secret (will be ignored if empty) |
| tls.certFilename | string | `""` | Certificate filename in the secret (will be ignored if empty) |
| tls.enabled | bool | `false` | Enable SSL/TLS |
| tls.existingSecret | string | `""` | Name of the secret containing the MariaDB certificates |
| tls.keyFilename | string | `""` | Certificate key filename in the secret (will be ignored if empty) |
| tls.requireSecureTransport | bool | `false` | When this option is enabled, connections attempted using insecure transport will be rejected |
| upgrade.backup.enabled | bool | `true` | Create a backup of the system database in the datadir before the upgrade |
| upgrade.enabled | bool | `false` | Allow to run the mariadb-upgrade if needed |

### Override Values

To override a parameter, add *--set* flags to the *helm install* command. For example:

```sh
helm install my-release --set images.mariadb.tag=11.8.6 oci://dp.apps.rancher.io/charts/mariadb
```

Alternatively, you can override the parameter values using a custom YAML file with the *-f* flag. For example:

```sh
helm install my-release -f custom-values.yaml oci://dp.apps.rancher.io/charts/mariadb
```

Read more about [Values files](https://helm.sh/docs/chart_template_guide/values_files/) in the [Helm documentation](https://helm.sh/docs/).
